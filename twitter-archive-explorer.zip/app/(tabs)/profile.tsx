import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import { Calendar, Download, FileText, Settings } from 'lucide-react-native';
import { useArchiveStore } from '@/store/archiveStore';
import { colors } from '@/constants/colors';

export default function ProfileScreen() {
  const { archiveData } = useArchiveStore();
  
  // Calculate some stats
  const totalTweets = archiveData.totalTweets;
  const yearCount = archiveData.years.length;
  const firstYear = archiveData.years[0]?.year || 'N/A';
  const lastYear = archiveData.years[archiveData.years.length - 1]?.year || 'N/A';
  
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Archive Profile</Text>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={styles.profileHeader}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80' }} 
            style={styles.profileImage}
          />
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>John Doe</Text>
            <Text style={styles.profileHandle}>@johndoe</Text>
          </View>
        </View>
        
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{totalTweets}</Text>
            <Text style={styles.statLabel}>Tweets</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{yearCount}</Text>
            <Text style={styles.statLabel}>Years</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{firstYear}</Text>
            <Text style={styles.statLabel}>First Year</Text>
          </View>
        </View>
        
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Archive Information</Text>
          
          <View style={styles.infoItem}>
            <Calendar size={20} color={colors.primary} />
            <Text style={styles.infoText}>Archive period: {firstYear} - {lastYear}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <FileText size={20} color={colors.primary} />
            <Text style={styles.infoText}>Total tweets: {totalTweets}</Text>
          </View>
          
          <View style={styles.infoItem}>
            <Download size={20} color={colors.primary} />
            <Text style={styles.infoText}>Archive downloaded: June 15, 2023</Text>
          </View>
        </View>
        
        <View style={styles.actionsContainer}>
          <TouchableOpacity style={styles.actionButton}>
            <Settings size={20} color={colors.white} />
            <Text style={styles.actionButtonText}>Archive Settings</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={[styles.actionButton, styles.secondaryButton]}>
            <Download size={20} color={colors.primary} />
            <Text style={styles.secondaryButtonText}>Update Archive</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.aboutContainer}>
          <Text style={styles.aboutTitle}>About Twitter Archives</Text>
          <Text style={styles.aboutText}>
            Twitter archives contain all of your tweets, including retweets and replies, from the beginning of your Twitter activity. 
            This app helps you explore your archive with an interactive timeline view.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  content: {
    flex: 1,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  profileImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  profileHandle: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.primary,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  sectionContainer: {
    padding: 16,
    backgroundColor: colors.white,
    marginTop: 16,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    color: colors.text,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoText: {
    fontSize: 16,
    color: colors.text,
    marginLeft: 12,
  },
  actionsContainer: {
    padding: 16,
    backgroundColor: colors.white,
    marginTop: 16,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primary,
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  actionButtonText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 16,
    marginLeft: 8,
  },
  secondaryButton: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  secondaryButtonText: {
    color: colors.primary,
    fontWeight: '600',
    fontSize: 16,
    marginLeft: 8,
  },
  aboutContainer: {
    padding: 16,
    marginTop: 16,
    marginBottom: 32,
  },
  aboutTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
    color: colors.text,
  },
  aboutText: {
    fontSize: 14,
    lineHeight: 22,
    color: colors.textSecondary,
  },
});