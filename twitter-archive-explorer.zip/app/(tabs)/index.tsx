import React from 'react';
import { View, StyleSheet, SafeAreaView } from 'react-native';
import { useArchiveStore } from '@/store/archiveStore';
import TimelineHeader from '@/components/TimelineHeader';
import GlobalView from '@/components/GlobalView';
import YearView from '@/components/YearView';
import MonthView from '@/components/MonthView';
import DayView from '@/components/DayView';
import TweetView from '@/components/TweetView';
import { colors } from '@/constants/colors';

export default function TimelineScreen() {
  const { currentLevel } = useArchiveStore();

  const renderContent = () => {
    switch (currentLevel) {
      case 'global':
        return <GlobalView />;
      case 'year':
        return <YearView />;
      case 'month':
        return <MonthView />;
      case 'day':
        return <DayView />;
      case 'tweet':
        return <TweetView />;
      default:
        return <GlobalView />;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <TimelineHeader />
      <View style={styles.content}>
        {renderContent()}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
  },
});