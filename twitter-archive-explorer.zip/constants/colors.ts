export const colors = {
  primary: '#1DA1F2', // Twitter blue
  primaryLight: '#E8F5FE',
  secondary: '#657786', // Twitter gray
  background: '#FFFFFF',
  text: '#14171A',
  textSecondary: '#657786',
  border: '#E1E8ED',
  success: '#4BB543',
  error: '#FF3B30',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#F5F8FA',
};