import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useArchiveStore } from '@/store/archiveStore';
import TimelineBar from './TimelineBar';
import { colors } from '@/constants/colors';

export default function MonthView() {
  const { getCurrentMonthData, selectDay, selectedDay } = useArchiveStore();
  
  const monthData = getCurrentMonthData();
  
  if (!monthData) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No month data available</Text>
      </View>
    );
  }
  
  const dayData = monthData.days.map(day => {
    const date = new Date(day.date);
    return {
      id: day.date,
      label: date.getDate().toString(),
      count: day.tweetCount
    };
  });
  
  const maxCount = Math.max(...dayData.map(d => d.count));
  const monthDate = new Date(monthData.month + '-01');
  const monthName = monthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{monthData.tweetCount}</Text>
          <Text style={styles.statLabel}>Tweets in {monthName}</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>
            {Math.round(monthData.tweetCount / monthData.days.length)}
          </Text>
          <Text style={styles.statLabel}>Avg per Day</Text>
        </View>
      </View>
      
      <Text style={styles.sectionTitle}>Tweet Activity by Day in {monthName}</Text>
      <TimelineBar 
        data={dayData}
        maxCount={maxCount}
        onItemPress={selectDay}
        selectedId={selectedDay}
      />
      
      <Text style={styles.instructions}>
        Tap on a day to see tweets from that day.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.primary,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginHorizontal: 16,
    marginBottom: 8,
    color: colors.text,
  },
  instructions: {
    fontSize: 14,
    color: colors.textSecondary,
    marginHorizontal: 16,
    marginTop: 24,
    marginBottom: 16,
    lineHeight: 20,
    textAlign: 'center',
  },
});