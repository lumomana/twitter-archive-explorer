import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useArchiveStore } from '@/store/archiveStore';
import TweetItem from './TweetItem';
import { colors } from '@/constants/colors';

export default function TweetView() {
  const { getCurrentTweet } = useArchiveStore();
  
  const tweet = getCurrentTweet();
  
  if (!tweet) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>Tweet not found</Text>
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container}>
      <TweetItem tweet={tweet} />
      
      <View style={styles.metadataContainer}>
        <Text style={styles.metadataTitle}>Tweet Metadata</Text>
        
        <View style={styles.metadataItem}>
          <Text style={styles.metadataLabel}>Tweet ID</Text>
          <Text style={styles.metadataValue}>{tweet.id}</Text>
        </View>
        
        <View style={styles.metadataItem}>
          <Text style={styles.metadataLabel}>Created At</Text>
          <Text style={styles.metadataValue}>{new Date(tweet.created_at).toLocaleString()}</Text>
        </View>
        
        <View style={styles.metadataItem}>
          <Text style={styles.metadataLabel}>Favorites</Text>
          <Text style={styles.metadataValue}>{tweet.favorite_count}</Text>
        </View>
        
        <View style={styles.metadataItem}>
          <Text style={styles.metadataLabel}>Retweets</Text>
          <Text style={styles.metadataValue}>{tweet.retweet_count}</Text>
        </View>
        
        {tweet.media && tweet.media.length > 0 && (
          <View style={styles.metadataItem}>
            <Text style={styles.metadataLabel}>Media</Text>
            <Text style={styles.metadataValue}>{tweet.media.length} {tweet.media.length === 1 ? 'item' : 'items'}</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  metadataContainer: {
    padding: 16,
    backgroundColor: colors.white,
    marginTop: 16,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  metadataTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    color: colors.text,
  },
  metadataItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  metadataLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  metadataValue: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '500',
    maxWidth: '60%',
  },
});