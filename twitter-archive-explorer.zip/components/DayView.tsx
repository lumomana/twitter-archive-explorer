import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { useArchiveStore } from '@/store/archiveStore';
import TweetItem from './TweetItem';
import { colors } from '@/constants/colors';

export default function DayView() {
  const { getCurrentDayData, selectTweet } = useArchiveStore();
  
  const dayData = getCurrentDayData();
  
  if (!dayData) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No day data available</Text>
      </View>
    );
  }
  
  if (dayData.tweets.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No tweets on this day</Text>
      </View>
    );
  }
  
  const date = new Date(dayData.date);
  const formattedDate = date.toLocaleDateString('en-US', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric', 
    year: 'numeric' 
  });
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.dateTitle}>{formattedDate}</Text>
        <Text style={styles.tweetCount}>{dayData.tweetCount} tweets</Text>
      </View>
      
      <FlatList
        data={dayData.tweets}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TweetItem 
            tweet={item} 
            onPress={() => selectTweet(item.id)}
          />
        )}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  header: {
    padding: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  dateTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  tweetCount: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  listContent: {
    paddingBottom: 16,
  },
});