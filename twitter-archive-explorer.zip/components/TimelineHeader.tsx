import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { ChevronLeft, Home } from 'lucide-react-native';
import { useArchiveStore } from '@/store/archiveStore';
import { colors } from '@/constants/colors';
import { TimelineLevel } from '@/types/twitter';

interface TimelineHeaderProps {
  onSearch?: () => void;
}

export default function TimelineHeader({ onSearch }: TimelineHeaderProps) {
  const { 
    currentLevel, 
    selectedYear, 
    selectedMonth, 
    selectedDay,
    navigateToLevel
  } = useArchiveStore();

  const getTitle = () => {
    switch (currentLevel) {
      case 'global':
        return 'Twitter Archive';
      case 'year':
        return selectedYear || 'Year';
      case 'month': {
        if (!selectedMonth) return 'Month';
        const date = new Date(selectedMonth + '-01');
        return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      }
      case 'day': {
        if (!selectedDay) return 'Day';
        const date = new Date(selectedDay);
        return date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
      }
      case 'tweet':
        return 'Tweet';
      default:
        return 'Twitter Archive';
    }
  };

  const handleBack = () => {
    const levels: TimelineLevel[] = ['global', 'year', 'month', 'day', 'tweet'];
    const currentIndex = levels.indexOf(currentLevel);
    
    if (currentIndex > 0) {
      navigateToLevel(levels[currentIndex - 1]);
    }
  };

  const canGoBack = currentLevel !== 'global';

  return (
    <View style={styles.container}>
      <View style={styles.navigationContainer}>
        {canGoBack ? (
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <ChevronLeft color={colors.primary} size={24} />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={() => navigateToLevel('global')} style={styles.homeButton}>
            <Home color={colors.primary} size={22} />
          </TouchableOpacity>
        )}
        <Text style={styles.title}>{getTitle()}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  navigationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    marginRight: 8,
  },
  homeButton: {
    marginRight: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
});