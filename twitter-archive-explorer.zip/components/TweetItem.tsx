import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Heart, Repeat, MessageCircle, Share } from 'lucide-react-native';
import { Tweet } from '@/types/twitter';
import { colors } from '@/constants/colors';

interface TweetItemProps {
  tweet: Tweet;
  onPress?: () => void;
  compact?: boolean;
}

export default function TweetItem({ tweet, onPress, compact = false }: TweetItemProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <TouchableOpacity 
      style={[styles.container, compact && styles.compactContainer]} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.header}>
        <Image source={{ uri: tweet.user.profile_image_url }} style={styles.avatar} />
        <View style={styles.userInfo}>
          <Text style={styles.userName}>{tweet.user.name}</Text>
          <Text style={styles.userHandle}>@{tweet.user.screen_name}</Text>
        </View>
        <Text style={styles.date}>{formatDate(tweet.created_at)}</Text>
      </View>
      
      <Text style={styles.tweetText}>{tweet.text}</Text>
      
      {tweet.media && tweet.media.length > 0 && !compact && (
        <View style={styles.mediaContainer}>
          <Image 
            source={{ uri: tweet.media[0].url }} 
            style={styles.media} 
            resizeMode="cover"
          />
        </View>
      )}
      
      {!compact && (
        <View style={styles.actions}>
          <View style={styles.actionItem}>
            <MessageCircle size={16} color={colors.textSecondary} />
            <Text style={styles.actionText}>0</Text>
          </View>
          <View style={styles.actionItem}>
            <Repeat size={16} color={colors.textSecondary} />
            <Text style={styles.actionText}>{tweet.retweet_count}</Text>
          </View>
          <View style={styles.actionItem}>
            <Heart size={16} color={colors.textSecondary} />
            <Text style={styles.actionText}>{tweet.favorite_count}</Text>
          </View>
          <View style={styles.actionItem}>
            <Share size={16} color={colors.textSecondary} />
          </View>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  compactContainer: {
    padding: 12,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontWeight: '700',
    fontSize: 15,
    color: colors.text,
  },
  userHandle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  date: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  tweetText: {
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 12,
    color: colors.text,
  },
  mediaContainer: {
    marginBottom: 12,
    borderRadius: 12,
    overflow: 'hidden',
  },
  media: {
    width: '100%',
    height: 200,
    backgroundColor: colors.lightGray,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingRight: 40,
  },
  actionItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionText: {
    marginLeft: 4,
    fontSize: 13,
    color: colors.textSecondary,
  },
});