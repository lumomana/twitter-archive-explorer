import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useArchiveStore } from '@/store/archiveStore';
import TimelineBar from './TimelineBar';
import { colors } from '@/constants/colors';

export default function GlobalView() {
  const { archiveData, selectYear, selectedYear } = useArchiveStore();
  
  const yearData = archiveData.years.map(year => ({
    id: year.year,
    label: year.year,
    count: year.tweetCount
  }));
  
  const maxCount = Math.max(...yearData.map(y => y.count));
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{archiveData.totalTweets}</Text>
          <Text style={styles.statLabel}>Total Tweets</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{archiveData.years.length}</Text>
          <Text style={styles.statLabel}>Years</Text>
        </View>
      </View>
      
      <Text style={styles.sectionTitle}>Tweet Activity by Year</Text>
      <TimelineBar 
        data={yearData}
        maxCount={maxCount}
        onItemPress={selectYear}
        selectedId={selectedYear}
      />
      
      <Text style={styles.instructions}>
        Tap on a year to explore tweets from that period. You can zoom in further to months, days, and individual tweets.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.primary,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginHorizontal: 16,
    marginBottom: 8,
    color: colors.text,
  },
  instructions: {
    fontSize: 14,
    color: colors.textSecondary,
    marginHorizontal: 16,
    marginTop: 24,
    marginBottom: 16,
    lineHeight: 20,
    textAlign: 'center',
  },
});