import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useArchiveStore } from '@/store/archiveStore';
import TimelineBar from './TimelineBar';
import { colors } from '@/constants/colors';

export default function YearView() {
  const { getCurrentYearData, selectMonth, selectedMonth } = useArchiveStore();
  
  const yearData = getCurrentYearData();
  
  if (!yearData) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No year data available</Text>
      </View>
    );
  }
  
  const monthData = yearData.months.map(month => {
    const date = new Date(month.month + '-01');
    return {
      id: month.month,
      label: date.toLocaleDateString('en-US', { month: 'short' }),
      count: month.tweetCount
    };
  });
  
  const maxCount = Math.max(...monthData.map(m => m.count));
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{yearData.tweetCount}</Text>
          <Text style={styles.statLabel}>Tweets in {yearData.year}</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>
            {Math.round(yearData.tweetCount / 12)}
          </Text>
          <Text style={styles.statLabel}>Avg per Month</Text>
        </View>
      </View>
      
      <Text style={styles.sectionTitle}>Tweet Activity by Month in {yearData.year}</Text>
      <TimelineBar 
        data={monthData}
        maxCount={maxCount}
        onItemPress={selectMonth}
        selectedId={selectedMonth}
      />
      
      <Text style={styles.instructions}>
        Tap on a month to explore tweets from that period.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 24,
    paddingHorizontal: 16,
    backgroundColor: colors.white,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.primary,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginHorizontal: 16,
    marginBottom: 8,
    color: colors.text,
  },
  instructions: {
    fontSize: 14,
    color: colors.textSecondary,
    marginHorizontal: 16,
    marginTop: 24,
    marginBottom: 16,
    lineHeight: 20,
    textAlign: 'center',
  },
});