import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ArchiveData, DayData, MonthData, TimelineLevel, Tweet, YearData } from '@/types/twitter';
import { mockTwitterArchive } from '@/mocks/twitterData';

interface ArchiveState {
  // Data
  archiveData: ArchiveData;
  isLoading: boolean;
  
  // Navigation state
  currentLevel: TimelineLevel;
  selectedYear: string | null;
  selectedMonth: string | null;
  selectedDay: string | null;
  selectedTweet: string | null;
  
  // Actions
  setArchiveData: (data: ArchiveData) => void;
  setLoading: (loading: boolean) => void;
  navigateToLevel: (level: TimelineLevel) => void;
  selectYear: (year: string) => void;
  selectMonth: (month: string) => void;
  selectDay: (day: string) => void;
  selectTweet: (tweetId: string) => void;
  
  // Getters
  getCurrentYearData: () => YearData | null;
  getCurrentMonthData: () => MonthData | null;
  getCurrentDayData: () => DayData | null;
  getCurrentTweet: () => Tweet | null;
}

export const useArchiveStore = create<ArchiveState>()(
  persist(
    (set, get) => ({
      // Initial state
      archiveData: mockTwitterArchive,
      isLoading: false,
      currentLevel: 'global',
      selectedYear: null,
      selectedMonth: null,
      selectedDay: null,
      selectedTweet: null,
      
      // Actions
      setArchiveData: (data) => set({ archiveData: data }),
      setLoading: (loading) => set({ isLoading: loading }),
      
      navigateToLevel: (level) => {
        const state = get();
        
        // Reset selections for levels deeper than the target level
        if (level === 'global') {
          set({ 
            currentLevel: level,
            selectedYear: null,
            selectedMonth: null,
            selectedDay: null,
            selectedTweet: null
          });
        } else if (level === 'year') {
          set({ 
            currentLevel: level,
            selectedMonth: null,
            selectedDay: null,
            selectedTweet: null
          });
        } else if (level === 'month') {
          set({ 
            currentLevel: level,
            selectedDay: null,
            selectedTweet: null
          });
        } else if (level === 'day') {
          set({ 
            currentLevel: level,
            selectedTweet: null
          });
        } else {
          set({ currentLevel: level });
        }
      },
      
      selectYear: (year) => {
        set({ 
          selectedYear: year,
          currentLevel: 'year',
          selectedMonth: null,
          selectedDay: null,
          selectedTweet: null
        });
      },
      
      selectMonth: (month) => {
        set({ 
          selectedMonth: month,
          currentLevel: 'month',
          selectedDay: null,
          selectedTweet: null
        });
      },
      
      selectDay: (day) => {
        set({ 
          selectedDay: day,
          currentLevel: 'day',
          selectedTweet: null
        });
      },
      
      selectTweet: (tweetId) => {
        set({ 
          selectedTweet: tweetId,
          currentLevel: 'tweet'
        });
      },
      
      // Getters
      getCurrentYearData: () => {
        const { archiveData, selectedYear } = get();
        if (!selectedYear) return null;
        return archiveData.years.find(y => y.year === selectedYear) || null;
      },
      
      getCurrentMonthData: () => {
        const yearData = get().getCurrentYearData();
        const { selectedMonth } = get();
        if (!yearData || !selectedMonth) return null;
        return yearData.months.find(m => m.month === selectedMonth) || null;
      },
      
      getCurrentDayData: () => {
        const monthData = get().getCurrentMonthData();
        const { selectedDay } = get();
        if (!monthData || !selectedDay) return null;
        return monthData.days.find(d => d.date === selectedDay) || null;
      },
      
      getCurrentTweet: () => {
        const dayData = get().getCurrentDayData();
        const { selectedTweet } = get();
        if (!dayData || !selectedTweet) return null;
        return dayData.tweets.find(t => t.id === selectedTweet) || null;
      }
    }),
    {
      name: 'twitter-archive-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        // Only persist these fields
        selectedYear: state.selectedYear,
        selectedMonth: state.selectedMonth,
        selectedDay: state.selectedDay,
        selectedTweet: state.selectedTweet,
        currentLevel: state.currentLevel
      }),
    }
  )
);